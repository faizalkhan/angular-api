import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-categories',
  templateUrl: './course-categories.component.html',
  styleUrls: ['./course-categories.component.css']
})
export class CourseCategoriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
