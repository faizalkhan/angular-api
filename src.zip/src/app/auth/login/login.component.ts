import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {  Loginemployee } from './loginemployee';
import { EmployeeserviceService  } from '../employeeservice.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm:FormGroup;
  Error = false;
  message:string;
  constructor( private employeeservice: EmployeeserviceService, 
               private formbuilder:FormBuilder,
               private router:Router) { }

  ngOnInit() {

    this.setFormState()
  }

  setFormState():void
  {
       this.formbuilder.group({
          Username : ['',[Validators.required]],
          Password: ['',[Validators.required]]
         })
  }

 onSubmit()
{
  let login = this.loginForm.value;
  this.login(login);
}

login(loginemployee:Loginemployee)
{
       this.employeeservice.loginemployee(loginemployee).subscribe(

        employee => {
          var succ = employee;
           if(succ)
           {
            this.loginForm.reset();
           }

        } 


       );


}

}
