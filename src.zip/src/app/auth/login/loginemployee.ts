export class Loginemployee {

    Username : string;
    Password : string;
}
