export class Employee {
FirstName:string;
LastName :string;
EmailId : string;
Password: string;
}
