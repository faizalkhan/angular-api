import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from './employee';
import { Loginemployee } from './login/loginemployee';


@Injectable({
  providedIn: 'root'
})
export class EmployeeserviceService {

  url = "http://localhost:64065/"; 

  constructor(private http:HttpClient) { }
 createemployee(employee:Employee) : Observable <Employee> 
 {
   return this.http.post<Employee>(this.url+'api/Default2', employee);
 }
 loginemployee(loginemployee:Loginemployee): Observable <Employee> 
 {
   return this.http.post<Employee>(this.url+'api/Default2', loginemployee);
 }
}
